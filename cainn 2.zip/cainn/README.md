# CAiN
CAiN, küçük işletmelerin ürün fotoğraflarını saniyeler içinde farklı temalarda profesyonel görsellere dönüştüren bir mobil uygulama.

## Teknolojiler
- Expo + React Native + TypeScript
- FAL API (AI görsel üretim)
- Adapty (monetization)

## Kurulum
```bash
npm install
npx expo start
